import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:login/models/user.dart';

class AuthService {
  Future<User> logIn(String tenancyCode, String email, String password) async {
    Map<String, dynamic> request = {
      'tenancyCode': tenancyCode,
      'email': email,
      'password': password
    };
    final url = Uri.parse('https://dummyjson.com/auth/login');
    final response = await http.post(url, body: jsonEncode(request));

    if (response.statusCode == 200) {
      return User.fromJson(jsonDecode(response.body));
    } else {
      throw Exception('Failed to log in');
    }
  }
}
