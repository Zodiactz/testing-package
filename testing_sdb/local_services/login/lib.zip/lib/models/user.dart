class User {
  final String tenancyCode;
  final String email;
  final String password;

  User({
    required this.tenancyCode,
    required this.email,
    required this.password,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      tenancyCode: json['tenancyCode'],
      email: json['email'],
      password: json['password'],
    );
  }
}
